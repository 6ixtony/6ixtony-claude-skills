#!/usr/bin/env python3
"""Reverse a video (and its audio, unless dropped).

Uses ffmpeg's `reverse` (video) and `areverse` (audio) filters, which decode
and buffer the whole clip in memory -- long inputs cost real time and RAM,
which is why there is no length limit baked in here: it is the caller's job
to keep this to clips it makes sense to reverse (a few seconds to a couple of
minutes), not a workaround this tool applies for you.

Examples:
  python3 reverse.py input.mp4
  python3 reverse.py input.mp4 --no-audio -o backwards.mp4
"""
import argparse
import math
import sys

from _common.runner import with_mapped_chapters
from _common import add_common, apply_common, aac_args, cfr_args, cfr_filter, default_output, die, emit, ffmpeg_base, info, probe, run, video_args, X264_PRESETS, fmt_secs
from _common.emit import warn
from _common.decision import (HELD_FRAMES_WARN_BYTES, av_clip_length, av_trim, delivered_rate, frame_durations, frame_rate,
                              held_frames_bytes, stream_starts)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("-o", "--output", help="output file (default: <name>_reverse.<ext>)")
    ap.add_argument("--no-audio", action="store_true", help="drop audio instead of reversing it")
    ap.set_defaults(crf=18)  # --quality's default (the --crf alias was removed in 2.0)
    ap.add_argument("--preset", default="medium", choices=X264_PRESETS, help="x264 preset")
    add_common(ap)
    args = ap.parse_args()
    apply_common(args)

    meta = probe(args.input)
    if not meta.get("video"):
        die("input has no video stream")
    has_audio = bool(meta.get("audio")) and not args.no_audio

    output = args.output or default_output(args.input, "reverse")
    # keyed on what is held (every decoded frame), not on the length alone (A174): the estimate
    # loop.py --boomerang warns from, over the frames of the picture's length at its rate
    v = meta["video"]
    vdur = v.get("duration") or meta.get("duration") or 0.0
    frames = v.get("nb_frames") or vdur * (frame_rate(meta) or v.get("fps") or 30.0)
    held = held_frames_bytes(v, frames)
    if held > HELD_FRAMES_WARN_BYTES:
        warn(f"reverse holds about {held / 1024 ** 3:.1f} GiB of decoded frames in memory "
             f"({vdur:.0f}s of {v['width']}x{v['height']}) -- cut the part to reverse first (cut.py) if RAM is tight",
             "memory_heavy", duration=meta.get("duration"), bytes=held)
    cmd = ffmpeg_base() + ["-i", args.input]
    # A VFR source is put on the delivered grid before the reversal (#523). `reverse` hands its
    # frames the forward timestamps in order, so a reversed VFR picture kept its gaps where they
    # were in forward time: every flash of the 27 fps average clip came 0.19 s late against the
    # reversed sound (0.23 s without sound). On a constant grid the reversed picture is the forward
    # one mirrored. Each slot takes the last frame that starts before the slot ends (round=down),
    # which is the frame the reversed slot opens on: the nearest frame to its start (the forward
    # conform's choice) dropped a last frame that starts after the last slot's middle, and the
    # reversal then opened on the frame before it. The conformed picture's time base is one frame,
    # and a trim rescales its bound to it (a half-frame bound can round onto a frame and cut it:
    # freeze.py), so a microsecond base follows.
    reversed_conform = f"{cfr_filter(meta)}:round=down,settb=AVTB" if cfr_filter(meta) else ""
    if has_audio:
        # Both streams are reversed about one end (#409); each reversed about its own end put a sound
        # 0.6 s longer than its picture 0.396 s off. As in a join, both start at the first frame (the
        # sound shifted by the same constant, padded when it starts late) and end together, on the
        # first frame time at or after the clip's one length (av_clip_length: the picture's, or the
        # sound's when it runs more than a frame past it). The last frame is held and the sound
        # padded with silence to that end; the end is a frame time because a copied cut's stated
        # video length can run past its last frame (7.517 s for frames ending at 7.5). One graph for
        # both streams, as pad.py's padding needs. areverse keeps its input's timestamps in order,
        # so the reversed sound is retimed by its samples. The hold (tpad) runs before av_trim's
        # setpts: from FFmpeg 7.0 setpts leaves its output's frame rate unknown and its frames'
        # durations 0, so a tpad after it clones nothing (the picture stayed 0.6 s short on 7.1);
        # the closing fps gives the frames their durations back (frame_durations).
        # the rate the encoder line delivers (cfr_args: a VFR source is conformed to its average
        # rate), so the graph's closing fps and the output's -r are one grid: the graph closed on
        # r_frame_rate and -r then resampled it, 51 frames for 49 that ran 81 ms past the sound (A234)
        # The trim that drops the hold's spare clones stays on the source's own grid (half a frame
        # of r_frame_rate before the end): half a delivered frame cut a real last frame that sits
        # nearer the end than that, and reverse then opened on the one before it.
        rate = delivered_rate(meta) or frame_rate(meta) or meta["video"].get("fps") or 30.0
        length = av_clip_length(meta, rate)
        vlen = meta["video"].get("duration") or length
        end = math.ceil(length * rate - 1e-6) / rate
        vtrim, atrim = av_trim(stream_starts(meta)[0], None)
        conform = f"{reversed_conform}," if reversed_conform else ""
        cmd += ["-filter_complex",
                f"[0:v:0]tpad=stop_mode=clone:stop_duration={max(0.0, end - vlen) + 2 / rate:.6f},{vtrim},"
                f"{conform}trim=end={end - 0.5 / max(rate, frame_rate(meta) or rate):.6f},reverse,{frame_durations(meta, rate)}[v];"
                f"[0:a:0]{atrim},apad=whole_dur={end:.6f},atrim=end={end:.6f},areverse,asetpts=N/SR/TB[a]",
                "-map", "[v]", "-map", "[a]"]
    else:
        cmd += ["-vf", f"{reversed_conform},reverse" if reversed_conform else "reverse"]
    cmd += video_args(meta, args.crf, args.preset)
    cmd += cfr_args(meta)
    if has_audio:
        cmd += aac_args()
    else:
        cmd += ["-an"]
    span = float(meta.get("duration") or vdur or 0.0)
    cmd = with_mapped_chapters(cmd, meta, lambda t: span - t, span)  # chapters mirrored with the picture (#470)
    cmd.append(output)
    run(cmd)

    result = probe(output, role="output")
    info(f"wrote {output} ({fmt_secs(result['duration'])}, {result['video']['width']}x{result['video']['height']})")
    emit(output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
